#http_path = "/"
css_dir = "theme/css"
sass_dir = "scss"
images_dir = "theme/images"
fonts_dir = "theme/fonts"
javascripts_dir = "theme/js"

line_comments = FALSE
environment = :development
output_style = :expanded
# To enable relative paths to assets via compass helper functions. Uncomment:
relative_assets = true
asset_cache_buster :none
